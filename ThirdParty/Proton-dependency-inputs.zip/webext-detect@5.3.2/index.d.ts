export declare function disableWebextDetectPageCache(): void;
/** Indicates whether the code is being run on http(s):// pages (it could be in a content script or regular web context) */
export declare const isWebPage: () => boolean;
/** Indicates whether you're in extension contexts that have access to the chrome API */
export declare const isExtensionContext: () => boolean;
/** Indicates whether you're in a sandboxed page (-extension:// URL protocol, but no chrome.* API access) */
export declare const isSandboxedPage: () => boolean;
/** Indicates whether you're in a content script. Note that the MAIN world is not considered a content script. */
export declare const isContentScript: () => boolean;
/** Indicates whether you're in a background context */
export declare const isBackground: () => boolean;
/** Indicates whether you're in a background page */
export declare const isBackgroundPage: () => boolean;
/** Indicates whether you're in a background worker */
export declare const isBackgroundWorker: () => boolean;
/** Indicates whether you're in a persistent background page (as opposed to an Event Page or Background Worker, both of which can be unloaded by the browser) */
export declare const isPersistentBackgroundPage: () => boolean;
/** Indicates whether you're in an options page. This only works if the current page’s URL matches the one specified in the extension's `manifest.json` */
export declare const isOptionsPage: () => boolean;
/** Indicates whether you're in a side panel. This only works if the current page’s URL matches the one specified in the extension's `manifest.json` */
export declare const isSidePanel: () => boolean;
export declare const isActionPopup: () => boolean;
/** Indicates whether you're in the main dev tools page, the one specified in the extension's `manifest.json` `devtools_page` field. */
export declare const isMainDevToolsPage: () => boolean;
/** @deprecated Use `isMainDevToolsPage` instead */
export declare const isDevToolsPage: () => boolean;
/** Indicates whether you're in the dev tools page. Unlike `isDevToolsPage`, this works in any page that has the `chrome.devTools` API */
export declare const isDevTools: () => boolean;
/** Indicates whether you're in a document created via chrome.offscreen */
export declare const isOffscreenDocument: () => boolean;
/** Loosely detect Firefox via user agent */
export declare const isFirefox: () => boolean;
/** Loosely detect Chrome via user agent (might also include Chromium and forks like Opera) */
export declare const isChrome: () => boolean;
/** Loosely detect Safari via user agent */
export declare const isSafari: () => boolean;
/** Loosely detect Mobile Safari via user agent */
export declare const isMobileSafari: () => boolean;
declare const contextChecks: {
    readonly contentScript: () => boolean;
    readonly background: () => boolean;
    readonly options: () => boolean;
    readonly sidePanel: () => boolean;
    readonly actionPopup: () => boolean;
    readonly devTools: () => boolean;
    readonly devToolsPage: () => boolean;
    readonly offscreenDocument: () => boolean;
    readonly extension: () => boolean;
    readonly sandbox: () => boolean;
    readonly web: () => boolean;
};
export type ContextName = keyof typeof contextChecks;
export declare const contextNames: ContextName[];
/** Returns the first matching context among those defined in `ContextName`, depending on the current context. Returns "unknown" if no match is found. */
export declare function getContextName(): ContextName | 'unknown';
export {};
