export declare const onExtensionStart: Readonly<{
    addListener(callback: VoidCallback): void;
    removeListener(callback: VoidCallback): void;
}>;
