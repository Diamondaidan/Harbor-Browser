import { chrome } from 'jest-chrome';
import { describe, it, vi, expect, beforeEach, expectTypeOf, } from 'vitest';
import { oneEvent } from './one-event.js';
function helloFromTheOtherSide(greeting = 'hello') {
    chrome.runtime.onMessage.callListeners({ greeting }, // Message
    {}, // MessageSender object
    vi.fn());
}
describe('oneEvent', () => {
    beforeEach(() => {
        chrome.runtime.onMessage.clearListeners();
    });
    it('it should resolve when an event is received', async () => {
        expect(chrome.runtime.onMessage.hasListeners()).toBe(false);
        const eventPromise = oneEvent(chrome.runtime.onMessage);
        expect(chrome.runtime.onMessage.hasListeners()).toBe(true);
        await expect(eventPromise).toBePending();
        helloFromTheOtherSide();
        await expect(eventPromise).not.toBePending();
    });
    it('it should resolve when a specific event is received', async () => {
        expect(chrome.runtime.onMessage.hasListeners()).toBe(false);
        const eventPromise = oneEvent(chrome.runtime.onMessage, {
            filter: ({ greeting }) => greeting === 'sup',
        });
        expect(chrome.runtime.onMessage.hasListeners()).toBe(true);
        helloFromTheOtherSide();
        await expect(eventPromise).toBePending();
        helloFromTheOtherSide('sup');
        await expect(eventPromise).not.toBePending();
    });
    it('it should resolve original event\'s parameters', () => {
        const onMoved = oneEvent(chrome.tabs.onMoved, {
            filter(tabId, moveInfo) {
                expectTypeOf(tabId).toEqualTypeOf();
                expectTypeOf(moveInfo).toEqualTypeOf();
                return true;
            },
        });
        expectTypeOf(onMoved).toEqualTypeOf();
        const onMessage = oneEvent(chrome.runtime.onMessage, {
            filter(message, sender, sendResponse) {
                expectTypeOf(message).toEqualTypeOf();
                expectTypeOf(sender).toEqualTypeOf();
                expectTypeOf(sendResponse).toEqualTypeOf();
                return true;
            },
        });
        expectTypeOf(onMessage).toEqualTypeOf();
        const onChanged = oneEvent(chrome.cookies.onChanged, {
            filter(changeInfo) {
                expectTypeOf(changeInfo).toEqualTypeOf();
                return true;
            },
        });
        expectTypeOf(onChanged).toEqualTypeOf();
    });
});
