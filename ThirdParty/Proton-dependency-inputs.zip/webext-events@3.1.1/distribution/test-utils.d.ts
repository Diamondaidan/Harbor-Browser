export declare const sleep: (ms: number) => Promise<unknown>;
declare global {
    namespace jest {
        interface Matchers<R> {
            toBePending(): Promise<R>;
        }
    }
}
