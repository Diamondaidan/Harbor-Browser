export async function oneEvent(event, { filter, signal, } = {}) {
    if (signal?.aborted) {
        return;
    }
    return new Promise(resolve => {
        // TODO: VoidFunction should not be necessary, it's equivalent to using "any"
        const listener = (...parameters) => {
            if (!filter || filter(...parameters)) {
                resolve(parameters);
                event.removeListener(listener);
            }
        };
        event.addListener(listener);
        // TODO: The abort listener is left behind if never aborted
        signal?.addEventListener('abort', () => {
            resolve();
            event.removeListener(listener);
        });
    });
}
