type AnyFunction = (...parameters: any[]) => void;
type RemovableEvent<T = (...arguments_: unknown[]) => unknown> = {
    removeListener(callback: T): void;
    addListener(callback: T): void;
};
type EventParameters<Event extends RemovableEvent<AnyFunction>> = Parameters<Parameters<Event['addListener']>[0]>;
export declare function oneEvent<Event extends RemovableEvent<AnyFunction>>(event: Event, { filter, signal, }?: {
    filter?: (...parameters: EventParameters<Event>) => boolean;
    signal?: AbortSignal;
}): Promise<EventParameters<Event> | void>;
export {};
