export function addListener(event, listener, { signal, }) {
    if (signal?.aborted) {
        return;
    }
    event.addListener(listener);
    signal.addEventListener('abort', () => {
        event.removeListener(listener);
    }, { once: true });
}
