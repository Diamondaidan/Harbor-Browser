type OptionsWithSignal = {
    signal?: AbortSignal;
};
declare class OnContextInvalidated {
    #private;
    get signal(): AbortSignal;
    get promise(): Promise<void>;
    /**
     *
     * @param callback         The function to call when the context is invalidated
     * @param options.signal   The signal to remove the listener, like with the regular `addEventListener()`
     */
    addListener(callback: VoidCallback, { signal }?: OptionsWithSignal): void;
}
export declare const onContextInvalidated: OnContextInvalidated;
export declare const wasContextInvalidated: () => boolean;
export declare const _testing: typeof OnContextInvalidated;
export {};
