declare function loadFileModern(): Promise<string>;
declare function saveFileModern(text: string, suggestedName: string): Promise<void>;
export declare const loadFile: typeof loadFileModern;
export declare const saveFile: typeof saveFileModern;
export {};
